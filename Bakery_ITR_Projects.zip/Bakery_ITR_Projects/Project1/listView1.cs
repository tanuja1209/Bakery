﻿namespace Project1
{
    internal class listView1
    {
        private string[] arr;

        public listView1(string[] arr)
        {
            this.arr = arr;
        }
    }
}
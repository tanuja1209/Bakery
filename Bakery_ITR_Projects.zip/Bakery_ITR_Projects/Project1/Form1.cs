﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace Project1
{
    public partial class Form1 : Form
    {
        private SqlConnection con;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           string[] arr = new string[4];
            arr[0] = comboBox1.SelectedItem.ToString();
            arr[1] = textBox1.Text;
            arr[2] = textBox2.Text;
            arr[3] = textBox3.Text;

            ListViewItem lvi = new ListViewItem(arr);
            listView1.Items.Add(lvi);

            textBox4.Text = (Convert.ToInt16(textBox4.Text) + Convert.ToInt16(textBox3.Text)).ToString();

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Pharsan");
            comboBox1.Items.Add("Sev");
            comboBox1.Items.Add("Chips");
            comboBox1.Items.Add("Papdi");
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Sonpapdi");
            comboBox1.Items.Add("Chikki");
            comboBox1.Items.Add("Ladoos");
            comboBox1.Items.Add("Barfi");
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Choclate Flavour");
            comboBox1.Items.Add("Strawberry Flavour");
            comboBox1.Items.Add("Pineapple Flavour");
            comboBox1.Items.Add("Red Velvet Flavour");
            comboBox1.Items.Add("Black Forest Flavour");

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Choclate ");
            comboBox1.Items.Add("Strawberry ");
            comboBox1.Items.Add("Pineapple ");
            comboBox1.Items.Add("Red Velvet ");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedItem.ToString()=="Pharsan")
            { textBox1.Text = "80"; }
            else if (comboBox1.SelectedItem.ToString() == "Sev")
            { textBox1.Text = "50"; }
           else if (comboBox1.SelectedItem.ToString() == "Chips")
            { textBox1.Text = "20"; }
            else if (comboBox1.SelectedItem.ToString() == "Papdi")
            { textBox1.Text = "50"; }
            else if (comboBox1.SelectedItem.ToString() == "Sonpapdi")
            { textBox1.Text = "65"; }
            else if (comboBox1.SelectedItem.ToString() == "Chikki")
            { textBox1.Text = "40"; }
            else if (comboBox1.SelectedItem.ToString() == "Ladoos")
            { textBox1.Text = "100"; }
            else if (comboBox1.SelectedItem.ToString() == "Barfi")
            { textBox1.Text = "50"; }
            else if (comboBox1.SelectedItem.ToString() == "Choclate Flavour")
            { textBox1.Text = "250"; }
            else if (comboBox1.SelectedItem.ToString() == "Strawberry Flavour")
            { textBox1.Text = "230"; }
            else if (comboBox1.SelectedItem.ToString() == "Pineapple Flavour")
            { textBox1.Text = "300"; }
            else if (comboBox1.SelectedItem.ToString() == "Red velvet Flavour")
            { textBox1.Text = "400"; }
            else if (comboBox1.SelectedItem.ToString() == "Black Foest Flavour")
            { textBox1.Text = "350"; }
            else if (comboBox1.SelectedItem.ToString() == "Choclate")
            { textBox1.Text = "45"; }
            else if (comboBox1.SelectedItem.ToString() == "Strawberry")
            { textBox1.Text = "60"; }
            else if (comboBox1.SelectedItem.ToString() == "Pineapple")
            { textBox1.Text = "65"; }
            else if (comboBox1.SelectedItem.ToString() == "Red velvet")
            { textBox1.Text = "80"; }
            else
            { textBox1.Text = ""; }

            textBox3.Text = "";
            textBox2.Text = "";

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox3.Text =(Convert.ToInt16(textBox1.Text) * Convert.ToInt16(textBox2.Text)).ToString();
        }

      

        private void button2_Click(object sender, EventArgs e)
        {

            String items = comboBox1.SelectedItem.ToString();
            String Price=textBox1.Text;
            String Qty = textBox2.Text;
            String Total=textBox3.Text;
            String Subtotal=textBox4.Text;
            String Discount = textBox5.Text;
            String Paid = textBox6.Text;
            SqlConnection con;
            con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=S1;User ID=sa;Password=Tanuja;");
            con.Open();
            SqlCommand cmd = new SqlCommand();
            
            cmd.CommandText = "Insert into bakery values ('" + items + "',' " + Price + "','" + Qty + "','" + Total + "','" + Subtotal + "','"+Discount+"','"+Paid+"')";
            cmd.Connection = con;
            //cmd.ExecuteNonQuery();
            MessageBox.Show("Order Saved Successfully!!");
           
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox6.Text = (Convert.ToInt32(textBox4.Text) -Convert.ToInt32(textBox5.Text)).ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
